#!/data/data/com.termux/files/usr/bin/bash
# MiniOS ana dizinine git
cd "$(dirname "$0")"
cd /data/data/com.termux/files/usr/share/minios/
bash /data/data/com.termux/files/usr/share/minios/minios.sh "$@"
